package com.dev.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.common.Command;
import com.dev.common.HttpUtil;
import com.dev.service.GoodService;
import com.dev.serviceImpl.GoodDAO;
import com.dev.vo.GoodVO;

public class GoodsDetailController implements Command {

	   @Override
	   public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      String path = "good/goodsDetail.tiles";
	      String prodCode = request.getParameter("prodCode");
	      
	      GoodService service = new GoodDAO();
	      GoodVO vo = service.selectItem(prodCode);
	      
	      request.setAttribute("goods", vo);
	      HttpUtil.forward(request, response, path);
	      
	      
	   }

	}
