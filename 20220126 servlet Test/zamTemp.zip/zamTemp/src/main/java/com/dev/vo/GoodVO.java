package com.dev.vo;

// 데이터베이스 테이블에 대응되도록 필드를 설정하세요.
public class GoodVO {
	private String prodCode;
	private String prodName;
	private String prodDesc;
	private String prodImage;
	private int prodPrice;
	private int salePrice;
	private double likeIt;

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public String getProdImage() {
		return prodImage;
	}

	public void setProdImage(String prodImage) {
		this.prodImage = prodImage;
	}

	public int getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(int prodPrice) {
		this.prodPrice = prodPrice;
	}

	public int getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(int salePrice) {
		this.salePrice = salePrice;
	}

	public double getLikeIt() {
		return likeIt;
	}

	public void setLikeIt(double likeIt) {
		this.likeIt = likeIt;
	}

	@Override
	public String toString() {
		return "GoodVO [prodCode=" + prodCode + ", prodName=" + prodName + ", prodDesc=" + prodDesc + ", prodImage="
				+ prodImage + ", prodPrice=" + prodPrice + ", salePrice=" + salePrice + ", likeIt=" + likeIt + "]";
	}

}
