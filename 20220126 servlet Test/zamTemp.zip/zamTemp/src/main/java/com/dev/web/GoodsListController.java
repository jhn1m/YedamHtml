package com.dev.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.common.Command;
import com.dev.common.HttpUtil;
import com.dev.service.GoodService;
import com.dev.serviceImpl.GoodDAO;
import com.dev.vo.GoodVO;

public class GoodsListController implements Command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GoodService service = new GoodDAO();
		List<GoodVO> list = service.itemList();
		
		request.setAttribute("goodsList", list);
		
		String path="good/goodsList.tiles";
		HttpUtil.forward(request, response, path);
	}

}
