package com.dev.serviceImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dev.common.DAO;
import com.dev.service.GoodService;
import com.dev.vo.GoodVO;

// GoodService를 구현하는 클래스.
public class GoodDAO extends DAO implements GoodService {

	@Override
	public List<GoodVO> itemList() {
		connect();
		String sql = "select * from goods order by 1";
		List<GoodVO> itemList = new ArrayList<>();
		try {
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();

			while (rs.next()) {
				GoodVO vo = new GoodVO();
				vo.setProdCode(rs.getString("prod_code"));
				vo.setProdName(rs.getString("prod_name"));
				vo.setProdDesc(rs.getString("prod_desc"));
				vo.setProdImage(rs.getString("prod_Image"));
				vo.setProdPrice(rs.getInt("prod_price"));
				vo.setSalePrice(rs.getInt("sale_price"));
				vo.setLikeIt(rs.getDouble("like_it"));
				itemList.add(vo);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return itemList;
	}

	@Override
	public GoodVO selectItem(String prodCode) {
		String sql = "select * from goods where prod_code=?";
		connect();
		GoodVO item = null;
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, prodCode);
			rs = psmt.executeQuery();
			if (rs.next()) {
				item = new GoodVO();
				item.setProdCode(rs.getString("prod_code"));
				item.setProdName(rs.getString("prod_name"));
				item.setProdDesc(rs.getString("prod_desc"));
				item.setProdImage(rs.getString("prod_Image"));
				item.setProdPrice(rs.getInt("prod_price"));
				item.setSalePrice(rs.getInt("sale_price"));
				item.setLikeIt(rs.getDouble("like_it"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return item;
	}
}